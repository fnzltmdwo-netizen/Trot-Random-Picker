import org.gradle.api.tasks.bundling.Zip

plugins {
    id("com.android.application")
}

android {
    namespace = "com.mandarin.chiyeonwidget"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mandarin.chiyeonwidget"
        minSdk = 26
        targetSdk = 36
        versionCode = 18
        versionName = "1.4.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// SAI convenience: every normal debug build also exports a real .apks ZIP
// containing the freshly built APK plus SAI metadata.
val saiMetaDir = layout.buildDirectory.dir("generated/saiMeta")
val packageSaiApks = tasks.register<Zip>("packageSaiApks") {
    group = "build"
    description = "Package app-debug.apk into an SAI-compatible .apks archive"

    val debugApk = layout.buildDirectory.file("outputs/apk/debug/app-debug.apk")
    from(debugApk) {
        rename { "base.apk" }
    }

    from(saiMetaDir)
    archiveFileName.set("ChiyeonComfortWidget-v1.4.1-debug.apks")
    destinationDirectory.set(layout.buildDirectory.dir("outputs/apks"))

    doFirst {
        val dir = saiMetaDir.get().asFile
        dir.mkdirs()
        val meta = dir.resolve("meta.sai_v1.json")
        meta.writeText(
            """{
              "export_timestamp":${System.currentTimeMillis()},
              "label":"치연 위젯",
              "package":"com.mandarin.chiyeonwidget",
              "version_code":18,
              "version_name":"1.4.1"
            }""".trimIndent()
        )
    }
}

// AIDE/AndroidIDE's normal Debug build invokes assembleDebug, so the .apks
// is generated automatically immediately after the APK is built.
tasks.matching { it.name == "assembleDebug" }.configureEach {
    finalizedBy(packageSaiApks)
}
