package com.mandarin.chiyeonwidget;

import java.time.LocalTime;
import java.time.ZonedDateTime;

public enum TimeMood {
    MORNING("morning", "☀ 아침", "SUNRISE · CHIYEON", "하루를 막 시작하는 시간. 부담을 낮추고 천천히 출발하게 해준다."),
    DAY("day", "낮", "DAYLIGHT · CHIYEON", "일과 활동이 한창인 시간. 실수와 업무 압박을 줄이고 지금 할 한 가지에 집중하게 해준다."),
    AFTER_WORK("after_work", "퇴근", "OFF WORK · CHIYEON", "하루 일을 내려놓는 시간. 버틴 것을 인정하고 일에서 마음을 떼어 쉬는 쪽으로 이끈다."),
    NIGHT("night", "☾ 밤", "NIGHT · CHIYEON", "하루를 마무리하는 시간. 반성·걱정을 멈추고 씻기, 눕기, 잠들기처럼 회복을 우선한다.");

    private final String key;
    private final String label;
    private final String clockLabel;
    private final String promptHint;

    TimeMood(String key, String label, String clockLabel, String promptHint) {
        this.key = key;
        this.label = label;
        this.clockLabel = clockLabel;
        this.promptHint = promptHint;
    }

    public String key() { return key; }
    public String label() { return label; }
    public String clockLabel() { return clockLabel; }
    public String promptHint() { return promptHint; }

    public static TimeMood current() { return fromHour(LocalTime.now().getHour()); }

    public static TimeMood fromHour(int hour) {
        if (hour >= 5 && hour < 11) return MORNING;
        if (hour >= 11 && hour < 17) return DAY;
        if (hour >= 17 && hour < 21) return AFTER_WORK;
        return NIGHT;
    }

    public static long nextBoundaryMillis() {
        ZonedDateTime now = ZonedDateTime.now();
        int hour = now.getHour();
        ZonedDateTime next;
        if (hour < 5) next = now.withHour(5).withMinute(0).withSecond(0).withNano(0);
        else if (hour < 11) next = now.withHour(11).withMinute(0).withSecond(0).withNano(0);
        else if (hour < 17) next = now.withHour(17).withMinute(0).withSecond(0).withNano(0);
        else if (hour < 21) next = now.withHour(21).withMinute(0).withSecond(0).withNano(0);
        else next = now.plusDays(1).withHour(5).withMinute(0).withSecond(0).withNano(0);
        return next.toInstant().toEpochMilli();
    }
}
