package com.mandarin.chiyeonwidget;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class ChatGptExportImporter {
    private ChatGptExportImporter() {}

    public static final class Conversation {
        public final String title;
        public final String text;
        public final int turns;
        public final int chars;
        public final double updatedAt;
        public final String firstPreview;
        public final String lastPreview;

        Conversation(String title, String text, int turns, double updatedAt, String firstPreview, String lastPreview) {
            this.title = title == null || title.trim().isEmpty() ? "제목 없는 대화" : title.trim();
            this.text = text == null ? "" : text.trim();
            this.turns = turns;
            this.chars = this.text.length();
            this.updatedAt = updatedAt;
            this.firstPreview = firstPreview == null ? "" : firstPreview;
            this.lastPreview = lastPreview == null ? "" : lastPreview;
        }

        public String label() {
            return title + "\n" + turns + "턴 · " + chars + "자";
        }
    }

    public static List<Conversation> read(Context context, Uri uri) throws Exception {
        String json = readConversationsJson(context, uri);
        JSONArray root = new JSONArray(json);
        List<Conversation> out = new ArrayList<>();
        for (int i = 0; i < root.length(); i++) {
            JSONObject c = root.optJSONObject(i);
            if (c == null) continue;
            Conversation parsed = parseConversation(c);
            if (parsed != null && parsed.turns > 0 && parsed.chars > 0) out.add(parsed);
        }
        Collections.sort(out, new Comparator<Conversation>() {
            @Override public int compare(Conversation a, Conversation b) {
                return Double.compare(b.updatedAt, a.updatedAt);
            }
        });
        return out;
    }

    private static String readConversationsJson(Context context, Uri uri) throws Exception {
        InputStream raw = context.getContentResolver().openInputStream(uri);
        if (raw == null) throw new IllegalStateException("ZIP 파일을 열 수 없어.");
        try (ZipInputStream zin = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName() == null ? "" : e.getName().replace('\\', '/');
                if (name.equals("conversations.json") || name.endsWith("/conversations.json")) {
                    ByteArrayOutputStream bout = new ByteArrayOutputStream();
                    byte[] buf = new byte[32768];
                    int n;
                    while ((n = zin.read(buf)) >= 0) {
                        if (n > 0) bout.write(buf, 0, n);
                    }
                    return bout.toString("UTF-8");
                }
            }
        }
        throw new IllegalStateException("ZIP 안에서 conversations.json을 찾지 못했어. ChatGPT 데이터 내보내기 ZIP인지 확인해줘.");
    }

    private static Conversation parseConversation(JSONObject c) {
        String title = c.optString("title", "제목 없는 대화");
        double updated = c.optDouble("update_time", c.optDouble("create_time", 0d));
        JSONObject mapping = c.optJSONObject("mapping");
        if (mapping == null) return null;

        List<JSONObject> ordered = currentBranch(mapping, c.optString("current_node", ""));
        if (ordered.isEmpty()) ordered = chronological(mapping);

        StringBuilder text = new StringBuilder();
        int turns = 0;
        String firstPreview = "";
        String lastPreview = "";
        for (JSONObject node : ordered) {
            JSONObject msg = node.optJSONObject("message");
            if (msg == null) continue;
            JSONObject author = msg.optJSONObject("author");
            String role = author == null ? "" : author.optString("role", "");
            if (!"user".equals(role) && !"assistant".equals(role)) continue;
            String content = messageText(msg);
            if (content.trim().isEmpty()) continue;
            if (text.length() > 0) text.append("\n\n");
            text.append("user".equals(role) ? "USER\n" : "ASSISTANT\n").append(content.trim());
            String preview = content.trim().replace('\n', ' ');
            if (preview.length() > 100) preview = preview.substring(0, 100).trim() + "…";
            if (firstPreview.isEmpty()) firstPreview = preview;
            lastPreview = preview;
            turns++;
        }
        return new Conversation(title, text.toString(), turns, updated, firstPreview, lastPreview);
    }

    private static List<JSONObject> currentBranch(JSONObject mapping, String currentNode) {
        List<JSONObject> rev = new ArrayList<>();
        String id = currentNode == null ? "" : currentNode;
        int guard = 0;
        while (!id.isEmpty() && guard++ < 20000) {
            JSONObject node = mapping.optJSONObject(id);
            if (node == null) break;
            rev.add(node);
            Object parent = node.opt("parent");
            id = parent == null || parent == JSONObject.NULL ? "" : String.valueOf(parent);
        }
        Collections.reverse(rev);
        return rev;
    }

    private static List<JSONObject> chronological(JSONObject mapping) {
        List<JSONObject> nodes = new ArrayList<>();
        JSONArray names = mapping.names();
        if (names == null) return nodes;
        for (int i = 0; i < names.length(); i++) {
            JSONObject n = mapping.optJSONObject(names.optString(i));
            if (n != null && n.optJSONObject("message") != null) nodes.add(n);
        }
        Collections.sort(nodes, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) {
                JSONObject am = a.optJSONObject("message");
                JSONObject bm = b.optJSONObject("message");
                double at = am == null ? 0 : am.optDouble("create_time", 0);
                double bt = bm == null ? 0 : bm.optDouble("create_time", 0);
                return Double.compare(at, bt);
            }
        });
        return nodes;
    }

    private static String messageText(JSONObject msg) {
        JSONObject content = msg.optJSONObject("content");
        if (content == null) return "";
        StringBuilder b = new StringBuilder();
        JSONArray parts = content.optJSONArray("parts");
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                Object p = parts.opt(i);
                if (p instanceof String) {
                    String s = ((String) p).trim();
                    if (!s.isEmpty()) {
                        if (b.length() > 0) b.append("\n");
                        b.append(s);
                    }
                } else if (p instanceof JSONObject) {
                    JSONObject o = (JSONObject)p;
                    String s = o.optString("text", "");
                    if (!s.trim().isEmpty()) {
                        if (b.length() > 0) b.append("\n");
                        b.append(s.trim());
                    }
                }
            }
        }
        if (b.length() == 0) {
            String t = content.optString("text", "");
            if (!t.trim().isEmpty()) b.append(t.trim());
        }
        return b.toString();
    }
}
