package com.mandarin.chiyeonwidget;

import java.util.concurrent.ThreadLocalRandom;

public final class LocalComfortBank {
    private LocalComfortBank() {}

    private static final String[] MORNING = {
            "아 진짜, 눈 뜬 것부터 잘했어. 오늘도 하나씩만 하자.",
            "됐어. 아침부터 완벽할 필요 없어. 천천히 가.",
            "아휴, 아직 덜 깼지? 물 한 잔 마시고 슬슬 시작해.",
            "뭐 어때. 오늘 컨디션 별로면 속도 좀 줄이면 되지.",
            "오늘도 시작했네. 벌써부터 너 몰아붙이지 마.",
            "아 진짜, 아침 걱정은 좀 작게 해. 지금 할 것만 보자.",
            "그래, 오늘은 네 페이스로 가. 급할 거 없어.",
            "일어나기 싫었지? 그래도 일어났잖아. 그럼 됐어.",
            "아휴, 출발부터 힘 빼지 마. 하나 하고 하나 쉬어.",
            "됐어, 오늘 하루 아직 안 망했어. 이제 막 시작이야.",
            "아 진짜, 눈 뜨자마자 반성 금지. 씻고 밥부터 챙겨.",
            "뭐 어때. 늦게 시동 걸려도 결국 가면 되는 거야."
    };

    private static final String[] DAY = {
            "아 진짜, 지금 좀 버벅여도 결국 하고 있잖아. 그거면 돼.",
            "뭐 어때. 하나 꼬였다고 하루가 다 망한 건 아니야.",
            "됐어. 다 잘하려고 하지 마. 중요한 것부터 해.",
            "아휴, 머리 복잡하지? 지금 하나만 끝내고 쉬자.",
            "너무 혼자 끙끙대지 마. 오늘은 네 편부터 해.",
            "그래, 짜증날 만했어. 근데 네 에너지까지 다 주진 마.",
            "아 진짜, 힘든 건 힘든 거야. 괜찮은 척 안 해도 돼.",
            "오늘 좀 느려도 돼. 멈춘 거 아니면 된 거야.",
            "뭐야, 벌써 이만큼 했네. 네가 생각한 것보다 많이 했어.",
            "됐어. 실수 하나로 너까지 미워하지 마.",
            "아휴, 신경 쓸 게 너무 많았지. 하나는 내려놔도 돼.",
            "지금 답 안 나와도 괜찮아. 급하게 결론 내리지 마."
    };

    private static final String[] AFTER_WORK = {
            "아휴, 오늘도 끝까지 버틴 거면 진짜 잘한 거야. 이제 좀 쉬자.",
            "됐어. 회사 생각은 문 앞에 두고 들어가. 오늘은 끝났어.",
            "아 진짜, 퇴근했으면 이제 네 시간이지. 밥부터 챙겨.",
            "뭐 어때. 오늘 못 끝낸 건 내일 하면 되지. 지금 내려놔.",
            "그래, 오늘 고생한 거 알아. 집 가서는 아무것도 안 해도 돼.",
            "아휴, 하루 종일 사람 상대했지? 이제 조용한 데 좀 있어.",
            "됐어. 퇴근까지 왔으면 오늘 할 만큼 한 거야.",
            "아 진짜, 일은 끝났는데 머리만 야근시키지 마.",
            "뭐야, 오늘도 살아서 퇴근했네. 잘했다 진짜.",
            "그래, 씻고 편한 옷 입자. 오늘 일은 거기까지만.",
            "아휴, 지금 필요한 건 평가가 아니라 저녁이야. 뭐라도 먹어.",
            "됐어. 오늘 일은 오늘 회사에 두고 와. 네가 다 들고 오지 마."
    };

    private static final String[] NIGHT = {
            "됐어, 오늘 못한 건 내일 하면 돼. 지금은 마음부터 눕혀.",
            "아 진짜, 오늘도 끝까지 왔네. 이제 좀 쉬어.",
            "아휴, 하루 종일 고생했지? 따뜻한 거 먹고 푹 쉬어.",
            "뭐 어때. 오늘 좀 엉망이었어도 하루는 끝났어.",
            "오늘 생각은 여기까지만. 침대까지 걱정 들고 가지 마.",
            "그래, 오늘도 잘 버텼어. 이제 네 몸부터 챙겨.",
            "아 진짜, 밤에는 생각이 더 커져. 결론은 내일 내자.",
            "됐어. 지금은 반성 말고 회복할 시간이야.",
            "서운한 건 서운한 거지. 그래도 오늘은 네 마음 좀 달래자.",
            "아휴, 너무 오래 애썼어. 오늘은 그냥 쉬어도 돼.",
            "뭐 어때. 내일 다시 시작하면 되지. 오늘은 여기까지.",
            "됐어, 폰 내려놓고 눈 좀 쉬자. 내일의 네가 이어서 하면 돼."
    };

    public static String defaultQuote() {
        return pick(TimeMood.current());
    }

    public static String pick() {
        return pick(TimeMood.current());
    }

    public static String pick(TimeMood mood) {
        String[] source;
        switch (mood) {
            case MORNING: source = MORNING; break;
            case DAY: source = DAY; break;
            case AFTER_WORK: source = AFTER_WORK; break;
            case NIGHT:
            default: source = NIGHT; break;
        }
        return source[ThreadLocalRandom.current().nextInt(source.length)];
    }
}
