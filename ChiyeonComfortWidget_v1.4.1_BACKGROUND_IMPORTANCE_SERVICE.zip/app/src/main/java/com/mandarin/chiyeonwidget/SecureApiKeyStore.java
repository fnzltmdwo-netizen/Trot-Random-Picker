package com.mandarin.chiyeonwidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class SecureApiKeyStore {
    private static final String STORE = "chiyeon_secret_store";
    private static final String KEY_VALUE = "openai_api_key";
    private static final String ALIAS = "chiyeon_openai_api_key_v1";

    private SecureApiKeyStore() {}

    public static void save(Context context, String plain) {
        try {
            if (plain == null || plain.trim().isEmpty()) {
                prefs(context).edit().remove(KEY_VALUE).apply();
                return;
            }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] iv = cipher.getIV();
            byte[] enc = cipher.doFinal(plain.trim().getBytes(StandardCharsets.UTF_8));
            ByteBuffer buf = ByteBuffer.allocate(4 + iv.length + enc.length);
            buf.putInt(iv.length).put(iv).put(enc);
            prefs(context).edit().putString(KEY_VALUE, Base64.encodeToString(buf.array(), Base64.NO_WRAP)).apply();
        } catch (Exception e) {
            throw new IllegalStateException("API Key 암호화 저장 실패", e);
        }
    }

    public static String load(Context context) {
        String saved = prefs(context).getString(KEY_VALUE, "");
        if (saved == null || saved.isEmpty()) return "";
        try {
            ByteBuffer buf = ByteBuffer.wrap(Base64.decode(saved, Base64.NO_WRAP));
            int ivLen = buf.getInt();
            if (ivLen < 12 || ivLen > 32) return "";
            byte[] iv = new byte[ivLen];
            buf.get(iv);
            byte[] enc = new byte[buf.remaining()];
            buf.get(enc);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(enc), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) {
            return (SecretKey) ks.getKey(ALIAS, null);
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return kg.generateKey();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }
}
