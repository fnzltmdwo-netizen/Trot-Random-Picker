package com.mandarin.chiyeonwidget;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String NAME = "chiyeon_widget_prefs";
    private static final String KEY_SHARE = "share_url";
    private static final String KEY_STYLE = "style_profile";
    private static final String KEY_USER_CONTEXT = "user_context";
    private static final String KEY_CONTEXT_ITEMS = "context_items";
    private static final String KEY_QUOTE = "last_quote";
    private static final String KEY_SOURCE_CHARS = "source_chars";
    private static final String KEY_ANALYZED_AT = "analyzed_at";
    private static final String KEY_LAST_MOOD = "last_mood";
    private static final String KEY_VISUAL_REV = "visual_revision";
    private static final String KEY_MASTER_TITLE = "master_title";
    private static final String KEY_MASTER_TURNS = "master_turns";
    private static final String KEY_MASTER_FIRST = "master_first";
    private static final String KEY_MASTER_LAST = "master_last";
    private static final String KEY_MOBILE_CAPTURE_ACTIVE = "mobile_capture_active";
    private static final String KEY_MOBILE_CAPTURE_READY = "mobile_capture_ready";
    private static final String KEY_MOBILE_CAPTURE_CHARS = "mobile_capture_chars";
    private static final String KEY_MOBILE_CAPTURE_FIRST = "mobile_capture_first";
    private static final String KEY_MOBILE_CAPTURE_LAST = "mobile_capture_last";
    private static final String KEY_CONTEXT_ROTATION = "context_rotation";
    private static final String KEY_IMPORTANCE_RUNNING = "importance_running";
    private static final String KEY_IMPORTANCE_STATUS = "importance_status";
    private static final String KEY_IMPORTANCE_SUCCESS = "importance_success";

    private Prefs() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static String apiKey(Context c) { return SecureApiKeyStore.load(c); }
    public static String shareUrl(Context c) { return p(c).getString(KEY_SHARE, ""); }
    public static String styleProfile(Context c) { return p(c).getString(KEY_STYLE, DefaultStyle.PROFILE); }
    public static String userContext(Context c) { return p(c).getString(KEY_USER_CONTEXT, ""); }
    public static int contextItems(Context c) { return Math.min(20, Math.max(0, p(c).getInt(KEY_CONTEXT_ITEMS, 0))); }
    public static String quote(Context c) { return p(c).getString(KEY_QUOTE, LocalComfortBank.defaultQuote()); }
    public static int sourceChars(Context c) { return p(c).getInt(KEY_SOURCE_CHARS, 0); }
    public static long analyzedAt(Context c) { return p(c).getLong(KEY_ANALYZED_AT, 0L); }
    public static String lastMood(Context c) { return p(c).getString(KEY_LAST_MOOD, ""); }
    public static int visualRevision(Context c) { return p(c).getInt(KEY_VISUAL_REV, 0); }
    public static String masterTitle(Context c) { return p(c).getString(KEY_MASTER_TITLE, ""); }
    public static int masterTurns(Context c) { return p(c).getInt(KEY_MASTER_TURNS, 0); }
    public static String masterFirst(Context c) { return p(c).getString(KEY_MASTER_FIRST, ""); }
    public static String masterLast(Context c) { return p(c).getString(KEY_MASTER_LAST, ""); }
    public static boolean mobileCaptureActive(Context c) { return p(c).getBoolean(KEY_MOBILE_CAPTURE_ACTIVE, false); }
    public static boolean mobileCaptureReady(Context c) { return p(c).getBoolean(KEY_MOBILE_CAPTURE_READY, false); }
    public static int mobileCaptureChars(Context c) { return p(c).getInt(KEY_MOBILE_CAPTURE_CHARS, 0); }
    public static String mobileCaptureFirst(Context c) { return p(c).getString(KEY_MOBILE_CAPTURE_FIRST, ""); }
    public static String mobileCaptureLast(Context c) { return p(c).getString(KEY_MOBILE_CAPTURE_LAST, ""); }
    public static boolean importanceRunning(Context c) { return p(c).getBoolean(KEY_IMPORTANCE_RUNNING, false); }
    public static String importanceStatus(Context c) { return p(c).getString(KEY_IMPORTANCE_STATUS, ""); }
    public static boolean importanceSuccess(Context c) { return p(c).getBoolean(KEY_IMPORTANCE_SUCCESS, false); }

    public static void setImportanceRunning(Context c, boolean running, String status) {
        p(c).edit().putBoolean(KEY_IMPORTANCE_RUNNING, running)
                .putString(KEY_IMPORTANCE_STATUS, status == null ? "" : status)
                .apply();
    }

    public static void finishImportanceAnalysis(Context c, boolean success, String status) {
        p(c).edit().putBoolean(KEY_IMPORTANCE_RUNNING, false)
                .putBoolean(KEY_IMPORTANCE_SUCCESS, success)
                .putString(KEY_IMPORTANCE_STATUS, status == null ? "" : status)
                .apply();
    }

    public static synchronized int nextContextRotation(Context c) {
        int current = Math.max(0, p(c).getInt(KEY_CONTEXT_ROTATION, 0));
        p(c).edit().putInt(KEY_CONTEXT_ROTATION, current + 1).apply();
        return current;
    }

    public static void saveSettings(Context c, String apiKey, String share) {
        SecureApiKeyStore.save(c, apiKey);
        p(c).edit().putString(KEY_SHARE, share == null ? "" : share.trim()).apply();
    }

    public static void saveStyle(Context c, String profile, int sourceChars, String userContext, int contextItems) {
        p(c).edit().putString(KEY_STYLE, profile)
                .putString(KEY_USER_CONTEXT, userContext == null ? "" : userContext)
                .putInt(KEY_CONTEXT_ITEMS, contextItems)
                .putInt(KEY_SOURCE_CHARS, sourceChars)
                .putLong(KEY_ANALYZED_AT, System.currentTimeMillis())
                .putInt(KEY_CONTEXT_ROTATION, 0).apply();
    }

    public static void resetStyle(Context c) {
        p(c).edit().putString(KEY_STYLE, DefaultStyle.PROFILE)
                .putString(KEY_USER_CONTEXT, "")
                .putInt(KEY_CONTEXT_ITEMS, 0)
                .putInt(KEY_SOURCE_CHARS, 0)
                .putLong(KEY_ANALYZED_AT, 0L).apply();
    }

    public static void setMobileCaptureActive(Context c, boolean active) {
        p(c).edit()
                .putBoolean(KEY_MOBILE_CAPTURE_ACTIVE, active)
                .putBoolean(KEY_MOBILE_CAPTURE_READY, false)
                .apply();
    }

    public static void saveMobileCaptureResult(Context c, boolean ready, int chars, String first, String last) {
        p(c).edit()
                .putBoolean(KEY_MOBILE_CAPTURE_ACTIVE, false)
                .putBoolean(KEY_MOBILE_CAPTURE_READY, ready)
                .putInt(KEY_MOBILE_CAPTURE_CHARS, chars)
                .putString(KEY_MOBILE_CAPTURE_FIRST, first == null ? "" : first)
                .putString(KEY_MOBILE_CAPTURE_LAST, last == null ? "" : last)
                .apply();
    }

    public static void consumeMobileCapture(Context c) {
        p(c).edit().putBoolean(KEY_MOBILE_CAPTURE_READY, false).apply();
    }

    public static void saveMasterMeta(Context c, String title, int turns, String first, String last) {
        p(c).edit()
                .putString(KEY_MASTER_TITLE, title == null ? "" : title)
                .putInt(KEY_MASTER_TURNS, turns)
                .putString(KEY_MASTER_FIRST, first == null ? "" : first)
                .putString(KEY_MASTER_LAST, last == null ? "" : last)
                .apply();
    }

    public static void saveQuote(Context c, String quote) {
        if (quote != null && !quote.trim().isEmpty()) {
            p(c).edit().putString(KEY_QUOTE, quote.trim()).apply();
        }
    }

    public static void saveMood(Context c, TimeMood mood) {
        p(c).edit().putString(KEY_LAST_MOOD, mood.key()).apply();
    }

    public static boolean isMoodChanged(Context c, TimeMood mood) {
        return !mood.key().equals(lastMood(c));
    }

    public static void bumpVisualRevision(Context c) {
        int next = visualRevision(c) + 1;
        p(c).edit().putInt(KEY_VISUAL_REV, next).apply();
    }
}
