package com.mandarin.chiyeonwidget;

import android.content.Context;
import android.graphics.Color;

import java.time.LocalDate;

public final class WidgetVisuals {
    private WidgetVisuals() {}

    private static final int[] MORNING_CHARACTERS = {
            R.drawable.chiyeon_045, R.drawable.chiyeon_066, R.drawable.chiyeon_068,
            R.drawable.chiyeon_086, R.drawable.chiyeon_092
    };
    private static final int[] DAY_CHARACTERS = {
            R.drawable.chiyeon_029, R.drawable.chiyeon_047, R.drawable.chiyeon_071,
            R.drawable.chiyeon_074, R.drawable.chiyeon_088
    };
    private static final int[] AFTER_WORK_CHARACTERS = {
            R.drawable.chiyeon_007, R.drawable.chiyeon_054, R.drawable.chiyeon_061,
            R.drawable.chiyeon_065, R.drawable.chiyeon_082, R.drawable.chiyeon_095
    };
    private static final int[] NIGHT_CHARACTERS = {
            R.drawable.chiyeon_016, R.drawable.chiyeon_018, R.drawable.chiyeon_055,
            R.drawable.chiyeon_062, R.drawable.chiyeon_064, R.drawable.chiyeon_096
    };

    private static final int[] MORNING_BACKGROUNDS = {
            R.drawable.widget_morning_1, R.drawable.widget_morning_2
    };
    private static final int[] DAY_BACKGROUNDS = {
            R.drawable.widget_day_1, R.drawable.widget_day_2
    };
    private static final int[] AFTER_WORK_BACKGROUNDS = {
            R.drawable.widget_evening_1, R.drawable.widget_evening_2
    };
    private static final int[] NIGHT_BACKGROUNDS = {
            R.drawable.widget_night_1, R.drawable.widget_night_2
    };

    public static Spec forMood(TimeMood mood) {
        switch (mood) {
            case MORNING:
                return new Spec(
                        MORNING_CHARACTERS, MORNING_BACKGROUNDS,
                        R.drawable.bubble_morning, R.drawable.widget_scrim_morning,
                        Color.parseColor("#FFFFE6EC"), Color.parseColor("#FF2A1B20")
                );
            case DAY:
                return new Spec(
                        DAY_CHARACTERS, DAY_BACKGROUNDS,
                        R.drawable.bubble_day, R.drawable.widget_scrim_day,
                        Color.parseColor("#FFFFF0D6"), Color.parseColor("#FF20242A")
                );
            case AFTER_WORK:
                return new Spec(
                        AFTER_WORK_CHARACTERS, AFTER_WORK_BACKGROUNDS,
                        R.drawable.bubble_evening, R.drawable.widget_scrim_evening,
                        Color.parseColor("#FFFFD8D8"), Color.parseColor("#FF2A1B20")
                );
            case NIGHT:
            default:
                return new Spec(
                        NIGHT_CHARACTERS, NIGHT_BACKGROUNDS,
                        R.drawable.bubble_night, R.drawable.widget_scrim_night,
                        Color.parseColor("#FFE6D9FF"), Color.parseColor("#FFF8F2FF")
                );
        }
    }

    public static int seed(Context context, TimeMood mood) {
        int day = LocalDate.now().getDayOfYear();
        int revision = Prefs.visualRevision(context);
        return (day * 1009) ^ (mood.ordinal() * 7919) ^ (revision * 104729);
    }

    public static int pick(int[] values, int seed) {
        return values[Math.floorMod(seed, values.length)];
    }

    public static final class Spec {
        public final int[] characters;
        public final int[] backgrounds;
        public final int bubbleRes;
        public final int scrimRes;
        public final int titleColor;
        public final int quoteColor;

        Spec(int[] characters, int[] backgrounds, int bubbleRes, int scrimRes,
             int titleColor, int quoteColor) {
            this.characters = characters;
            this.backgrounds = backgrounds;
            this.bubbleRes = bubbleRes;
            this.scrimRes = scrimRes;
            this.titleColor = titleColor;
            this.quoteColor = quoteColor;
        }
    }
}
