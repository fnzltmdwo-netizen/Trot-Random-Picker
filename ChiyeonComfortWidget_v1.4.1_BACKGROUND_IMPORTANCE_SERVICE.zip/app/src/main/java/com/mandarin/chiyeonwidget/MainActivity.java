package com.mandarin.chiyeonwidget;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.provider.Settings;
import android.content.ComponentName;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_FULL_COLLECT = 1334;
    private static final int REQ_EXPORT_ZIP = 1338;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText apiKey;
    private EditText shareUrl;
    private TextView status;
    private TextView previewQuote;
    private TextView previewTitle;
    private TextView previewClockLabel;
    private ImageView previewBg;
    private ImageView previewScrim;
    private ImageView previewChiyeon;
    private Button analyzeButton;
    private Button importExportZipButton;
    private Button mobileChatCaptureButton;
    private Button rebuildImportanceButton;
    private Button refreshButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apiKey = findViewById(R.id.api_key);
        shareUrl = findViewById(R.id.share_url);
        status = findViewById(R.id.status_text);
        previewQuote = findViewById(R.id.preview_quote);
        previewTitle = findViewById(R.id.preview_title);
        previewClockLabel = findViewById(R.id.preview_clock_label);
        previewBg = findViewById(R.id.preview_bg);
        previewScrim = findViewById(R.id.preview_scrim);
        previewChiyeon = findViewById(R.id.preview_chiyeon);
        analyzeButton = findViewById(R.id.analyze_button);
        importExportZipButton = findViewById(R.id.import_export_zip_button);
        mobileChatCaptureButton = findViewById(R.id.mobile_chat_capture_button);
        rebuildImportanceButton = findViewById(R.id.rebuild_importance_button);
        refreshButton = findViewById(R.id.refresh_button);

        apiKey.setText(Prefs.apiKey(this));
        shareUrl.setText(Prefs.shareUrl(this));
        previewQuote.setText(Prefs.quote(this));
        updatePreviewVisuals();
        updateStatus();

        analyzeButton.setOnClickListener(v -> analyzeShare());
        importExportZipButton.setOnClickListener(v -> openExportZip());
        mobileChatCaptureButton.setOnClickListener(v -> startMobileChatCapture());
        rebuildImportanceButton.setOnClickListener(v -> rebuildImportanceFromStoredMaster());
        refreshButton.setOnClickListener(v -> refreshComfort());
    }

    private void saveFields() {
        Prefs.saveSettings(this, apiKey.getText().toString(), shareUrl.getText().toString());
    }

    private void analyzeShare() {
        saveFields();
        final String key = Prefs.apiKey(this);
        final String share = Prefs.shareUrl(this);
        if (TextUtils.isEmpty(key) || TextUtils.isEmpty(share)) {
            toast("API Key랑 GPT 공유링크 두 개만 넣어줘.");
            return;
        }
        if (!share.startsWith("https://chatgpt.com/share/") && !share.startsWith("https://chat.openai.com/share/")) {
            toast("chatgpt.com/share/... 공개 공유링크를 넣어줘.");
            return;
        }
        setBusy(true, "GPT 공유대화를 처음부터 끝까지 전체수집하는 중…");
        Intent i = new Intent(this, FullConversationCollectorActivity.class);
        i.putExtra(FullConversationCollectorActivity.EXTRA_URL, share);
        i.putExtra(FullConversationCollectorActivity.EXTRA_PREVIOUS_CHARS, Prefs.sourceChars(this));
        startActivityForResult(i, REQ_FULL_COLLECT);
    }

    private void startMobileChatCapture() {
        saveFields();
        if (TextUtils.isEmpty(Prefs.apiKey(this))) {
            toast("먼저 OpenAI API Key를 넣어줘.");
            return;
        }
        if (!isMobileCaptureAccessibilityEnabled()) {
            toast("접근성 설정에서 '치연 위젯' 서비스를 켜고 다시 눌러줘.");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        Prefs.setMobileCaptureActive(this, true);
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(launch);
            toast("ChatGPT의 원하는 채팅 화면에서 기다려줘. 치연이 맨 처음→마지막까지 자동수집할게.");
        } else {
            // Android/package variants can still hide the launcher. Keep capture armed
            // and let the user switch to ChatGPT manually instead of cancelling.
            toast("수집 준비 완료! 이제 ChatGPT 앱으로 직접 전환해서 원하는 채팅을 열어줘.");
        }
    }

    private boolean isMobileCaptureAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName target = new ComponentName(this, ChatGptCaptureAccessibilityService.class);
        String full = target.flattenToString().toLowerCase(Locale.ROOT);
        String shortName = target.flattenToShortString().toLowerCase(Locale.ROOT);
        String all = enabled.toLowerCase(Locale.ROOT);
        return all.contains(full) || all.contains(shortName);
    }

    private boolean mobileImportRunning = false;

    private void consumeMobileCaptureIfReady() {
        if (!Prefs.mobileCaptureReady(this) || mobileImportRunning) return;

        String first = Prefs.mobileCaptureFirst(this);
        String last = Prefs.mobileCaptureLast(this);
        int pendingChars = Prefs.mobileCaptureChars(this);
        int appliedChars = Prefs.sourceChars(this);

        if (appliedChars > 0
                && pendingChars == appliedChars
                && last != null
                && last.equals(Prefs.masterLast(this))) {
            Prefs.consumeMobileCapture(this);
            updateStatus();
            return;
        }

        if (appliedChars >= 20000 && pendingChars > 0 && pendingChars < appliedChars * 0.85) {
            Prefs.consumeMobileCapture(this);
            status.setText("🛡 기존 MASTER " + appliedChars + "자 유지\n"
                    + "새 수집 " + pendingChars + "자는 불완전해 보여 자동으로 건너뛰었어.");
            return;
        }

        try {
            String full = GptMasterStore.read(this);
            if (full.trim().length() < 500) {
                status.setText("⚠️ 모바일 수집 원문이 너무 짧아 · " + full.length() + "자");
                return;
            }
            mobileImportRunning = true;
            analyzePersonalMaster("모바일 ChatGPT 현재 채팅", 0, first, last, full, true);
        } catch (Exception e) {
            mobileImportRunning = false;
            status.setText("모바일 MASTER 읽기 실패: " + friendlyError(e));
        }
    }

    private void openExportZip() {
        saveFields();
        if (TextUtils.isEmpty(Prefs.apiKey(this))) {
            toast("먼저 OpenAI API Key를 넣어줘.");
            return;
        }
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        startActivityForResult(i, REQ_EXPORT_ZIP);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_EXPORT_ZIP) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
            handleExportZip(data.getData());
            return;
        }

        if (requestCode != REQ_FULL_COLLECT) return;
        if (resultCode != RESULT_OK || data == null) {
            setBusy(false, "");
            toast("전체 대화 수집이 완료되지 않았어.");
            return;
        }
        final String full = data.getStringExtra(FullConversationCollectorActivity.EXTRA_TEXT);
        if (full == null || full.trim().length() < 800) {
            setBusy(false, "");
            toast("수집된 원문이 너무 짧아.");
            return;
        }
        analyzePersonalMaster("공유링크 MASTER", -1, "", "", full);
    }

    private void handleExportZip(Uri uri) {
        setBusy(true, "ChatGPT 내보내기 ZIP에서 전체 대화 목록을 읽는 중…");
        executor.execute(() -> {
            try {
                java.util.List<ChatGptExportImporter.Conversation> list = ChatGptExportImporter.read(this, uri);
                runOnUiThread(() -> {
                    setBusy(false, "");
                    if (list.isEmpty()) {
                        toast("ZIP에서 가져올 수 있는 ChatGPT 대화를 찾지 못했어.");
                        return;
                    }
                    String[] labels = new String[list.size()];
                    for (int i = 0; i < list.size(); i++) labels[i] = list.get(i).label();
                    new AlertDialog.Builder(this)
                            .setTitle("MASTER로 가져올 대화 선택")
                            .setItems(labels, (dialog, which) -> {
                                ChatGptExportImporter.Conversation c = list.get(which);
                                analyzePersonalMaster(c.title, c.turns, c.firstPreview, c.lastPreview, c.text);
                            })
                            .setNegativeButton("취소", null)
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setBusy(false, "");
                    status.setText("ZIP 읽기 실패: " + friendlyError(e));
                });
            }
        });
    }

    private void analyzePersonalMaster(String title, int turns, String firstPreview, String lastPreview, String full) {
        analyzePersonalMaster(title, turns, firstPreview, lastPreview, full, false);
    }

    private void analyzePersonalMaster(String title, int turns, String firstPreview, String lastPreview,
                                       String full, boolean fromMobileCapture) {
        final String key = Prefs.apiKey(this);
        if (TextUtils.isEmpty(key)) {
            toast("OpenAI API Key를 넣어줘.");
            return;
        }
        setBusy(true, "MASTER " + full.length() + "자는 그대로 보관 · FAST 중요도 분석 1회로 TOP8 고르는 중…");
        executor.execute(() -> {
            try {
                GptMasterStore.save(this, full);
                OpenAiDirectClient.AnalyzeResult result =
                        OpenAiDirectClient.analyzePersonalConversation(key, full);

                if (fromMobileCapture
                        && Prefs.sourceChars(this) >= 20000
                        && result.sourceChars < Prefs.sourceChars(this) * 0.85) {
                    throw new IllegalStateException("새 모바일 MASTER가 기존보다 너무 짧아서 기존 개인화를 보호했어.");
                }

                Prefs.saveStyle(this, result.styleProfile, result.sourceChars,
                        result.userContext, result.contextItems);
                Prefs.saveMasterMeta(this, title, turns, firstPreview, lastPreview);

                TimeMood mood = TimeMood.current();
                int rotation = Prefs.nextContextRotation(this);
                ContextRotation.Selection selected = ContextRotation.choose(
                        result.userContext, lastPreview == null ? "" : lastPreview, rotation);
                String quote = OpenAiDirectClient.generateComfort(
                        key, result.styleProfile, selected.context, selected.anchor, mood);
                Prefs.saveMood(this, mood);
                Prefs.saveQuote(this, quote);

                runOnUiThread(() -> {
                    previewQuote.setText(quote);
                    updatePreviewVisuals();
                    ChiyeonWidgetProvider.updateAll(this);
                    if (fromMobileCapture) {
                        Prefs.consumeMobileCapture(this);
                        mobileImportRunning = false;
                    }
                    setBusy(false, "");
                    updateStatus();
                    toast("GPT MASTER 유지 · FAST 중요도 TOP" + result.contextItems + " 선정 완료!");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (fromMobileCapture) mobileImportRunning = false;
                    setBusy(false, "");
                    if (fromMobileCapture && Prefs.mobileCaptureReady(this)) {
                        status.setText("⚠️ 수집은 완료됐지만 치연 분석 반영 실패\n"
                                + "수집 원문 " + Prefs.mobileCaptureChars(this) + "자 보존 중 · 다시 앱을 열면 재시도 가능\n"
                                + friendlyError(e));
                    } else {
                        status.setText("MASTER 분석 실패: " + friendlyError(e));
                    }
                });
            }
        });
    }

    private void rebuildImportanceFromStoredMaster() {
        saveFields();
        if (TextUtils.isEmpty(Prefs.apiKey(this))) {
            toast("먼저 OpenAI API Key를 넣어줘.");
            return;
        }
        if (Prefs.importanceRunning(this)) {
            toast("치연이 이미 중요 이야기 TOP8을 고르는 중이야. 화면 나가도 계속돼.");
            updateStatus();
            return;
        }
        try {
            String full = GptMasterStore.read(this);
            if (full == null || full.trim().length() < 500) {
                toast("저장된 GPT MASTER가 없어. 먼저 모바일 전체수집을 한 번 해줘.");
                return;
            }
            Intent service = new Intent(this, ImportanceAnalysisService.class);
            service.setAction(ImportanceAnalysisService.ACTION_REBUILD);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(service);
            } else {
                startService(service);
            }
            Prefs.setImportanceRunning(this, true,
                    "MASTER " + full.length() + "자 유지 · 백그라운드에서 중요 TOP8 고르는 중…");
            updateStatus();
            toast("시작했어. 이제 치연 앱 화면을 나가도 계속 분석해.");
        } catch (Exception e) {
            status.setText("중요 이야기 재분석 시작 실패: " + friendlyError(e));
        }
    }

    private void refreshComfort() {
        saveFields();
        final TimeMood mood = TimeMood.current();
        final String key = Prefs.apiKey(this);

        if (TextUtils.isEmpty(key)) {
            toast("API Key가 없어서 새 AI 대사는 만들 수 없어. 기존 개인화 대사는 그대로 둘게.");
            return;
        }

        setBusy(true, "MASTER " + Prefs.sourceChars(this) + "자 · 중요 이야기 "
                + Prefs.contextItems(this) + "개를 그대로 참고해서 치연 대사만 새로 만드는 중…");

        final String style = Prefs.styleProfile(this);
        final int rotation = Prefs.nextContextRotation(this);
        final ContextRotation.Selection selected = ContextRotation.choose(
                Prefs.userContext(this), Prefs.masterLast(this), rotation);

        executor.execute(() -> {
            try {
                String quote = OpenAiDirectClient.generateComfort(
                        key, style, selected.context, selected.anchor, mood);

                Prefs.saveMood(this, mood);
                Prefs.saveQuote(this, quote);
                Prefs.bumpVisualRevision(this);

                runOnUiThread(() -> {
                    previewQuote.setText(quote);
                    updatePreviewVisuals();
                    ChiyeonWidgetProvider.updateAll(this);
                    setBusy(false, "");
                    updateStatus();
                    toast("내 GPT 이야기 + 치연 말투로 새 대사만 만들었어.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setBusy(false, "");
                    status.setText("⚠️ 새 대사 생성 실패 · 기존 MASTER/개인화 대사는 그대로 유지\n"
                            + friendlyError(e));
                });
            }
        });
    }

    private void updatePreviewVisuals() {
        TimeMood mood = TimeMood.current();
        WidgetVisuals.Spec theme = WidgetVisuals.forMood(mood);
        int seed = WidgetVisuals.seed(this, mood);
        previewBg.setImageResource(WidgetVisuals.pick(theme.backgrounds, seed * 31 + 17));
        previewScrim.setImageResource(theme.scrimRes);
        previewChiyeon.setImageResource(WidgetVisuals.pick(theme.characters, seed));
        previewClockLabel.setText(mood.clockLabel());
        previewClockLabel.setTextColor(theme.titleColor);
        previewTitle.setText(mood.label() + " · 치연의 위로");
        previewTitle.setTextColor(theme.titleColor);
        previewQuote.setBackgroundResource(theme.bubbleRes);
        previewQuote.setTextColor(theme.quoteColor);
    }

    @Override
    protected void onResume() {
        super.onResume();
        apiKey.setText(Prefs.apiKey(this));
        previewQuote.setText(Prefs.quote(this));
        updatePreviewVisuals();
        updateStatus();
        consumeMobileCaptureIfReady();
    }

    private void updateStatus() {
        if (Prefs.importanceRunning(this)) {
            status.setText("🧠 " + Prefs.importanceStatus(this) + "\n화면을 나가도 계속 진행돼.");
            return;
        }
        String importanceDone = Prefs.importanceStatus(this);
        if (importanceDone != null && !importanceDone.trim().isEmpty()
                && (importanceDone.startsWith("✅") || importanceDone.startsWith("⚠️"))) {
            status.setText(importanceDone + "\n현재 MASTER " + Prefs.sourceChars(this)
                    + "자 · 중요 이야기 " + Prefs.contextItems(this) + "개");
            return;
        }
        if (Prefs.mobileCaptureActive(this)) {
            status.setText("📱 모바일 ChatGPT 현재 채팅 수집 중 · ChatGPT 화면에서 잠시 기다려줘.");
            return;
        }
        if (Prefs.mobileCaptureReady(this)) {
            status.setText("✅ 모바일 수집 완료 · " + Prefs.mobileCaptureChars(this) + "자\n"
                    + "마지막 대화: " + Prefs.mobileCaptureLast(this) + "\n"
                    + "지금 치연 개인화에 반영하는 중…");
            return;
        }
        int chars = Prefs.sourceChars(this);
        if (chars > 0) {
            String n = NumberFormat.getNumberInstance(Locale.KOREA).format(chars);
            String title = Prefs.masterTitle(this);
            int turns = Prefs.masterTurns(this);
            String last = Prefs.masterLast(this);
            if (!title.isEmpty()) {
                status.setText("현재 MASTER: " + title + " · " + turns + "턴 · " + n + "자 · 중요 이야기 "
                        + Prefs.contextItems(this) + "개\n마지막 대화: " + (last.isEmpty() ? "확인 정보 없음" : last)
                        + "\n" + TimeMood.current().label() + " 자동 모드");
            } else {
                status.setText("현재: 공유링크 원문 " + n + "자 학습 완료 · 중요 이야기 "
                        + Prefs.contextItems(this) + "개 참고 중 · " + TimeMood.current().label() + " 자동 모드");
            }
        } else {
            status.setText("현재: 치연 원문 2,647줄 기반 기본 말투 · " + TimeMood.current().label() + " 자동 모드");
        }
    }

    private void setBusy(boolean busy, String message) {
        analyzeButton.setEnabled(!busy);
        importExportZipButton.setEnabled(!busy);
        mobileChatCaptureButton.setEnabled(!busy);
        rebuildImportanceButton.setEnabled(!busy);
        refreshButton.setEnabled(!busy);
        if (busy) status.setText(message);
    }

    private String friendlyError(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return e.getClass().getSimpleName();
        return m.length() > 220 ? m.substring(0, 220) + "…" : m;
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
