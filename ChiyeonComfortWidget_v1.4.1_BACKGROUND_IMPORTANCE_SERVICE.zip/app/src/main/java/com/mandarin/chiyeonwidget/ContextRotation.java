package com.mandarin.chiyeonwidget;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ContextRotation {
    private ContextRotation() {}

    public static final class Selection {
        public final String context;
        public final String anchor;
        Selection(String context, String anchor) {
            this.context = context == null ? "" : context;
            this.anchor = anchor == null ? "" : anchor;
        }
    }

    // Top stories appear more often, but the lower-ranked important stories still rotate in.
    private static final int[] WEIGHTED_ORDER = {
            0,1,0,2,1,0,3,2,0,1,4,0,2,5,1,0,6,3,0,2,7,1
    };

    public static Selection choose(String fullContext, String latestAnchor, int rotation) {
        List<String> lines=new ArrayList<>();
        if(fullContext!=null){
            for(String line:fullContext.split("\\n")){
                String x=line==null?"":line.trim();
                if(!x.isEmpty() && !isMedicalTopic(x)) lines.add(x);
            }
        }

        String safeAnchor=isMedicalTopic(latestAnchor)?"":(latestAnchor==null?"":latestAnchor.trim());
        if(lines.isEmpty()) return new Selection("", rotation%5==0?safeAnchor:"");

        // Pick three important stories per generation. TOP1/TOP2 recur more often.
        StringBuilder chosen=new StringBuilder();
        boolean[] used=new boolean[lines.size()];
        int cursor=Math.floorMod(rotation*2,WEIGHTED_ORDER.length);
        int added=0;
        for(int tries=0;tries<WEIGHTED_ORDER.length*2 && added<3;tries++){
            int wanted=WEIGHTED_ORDER[(cursor+tries)%WEIGHTED_ORDER.length];
            int idx=Math.floorMod(wanted,lines.size());
            if(used[idx])continue;
            used[idx]=true;
            if(chosen.length()>0)chosen.append('\n');
            chosen.append(lines.get(idx));
            added++;
        }

        // The literal final GPT message is only an occasional tie-breaker.
        String anchor=rotation%5==0?safeAnchor:"";
        return new Selection(chosen.toString(),anchor);
    }

    public static boolean isMedicalTopic(String text) {
        if(text==null||text.trim().isEmpty())return false;
        String x=text.toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");
        String[] hard={
                "병원","진료","처방","복용","약국","의사","의료","진단","치료",
                "수술","입원","퇴원","응급실","검진","검사 결과","건강검진",
                "혈압","혈당","주사","약물","부작용","용량","처방전",
                "약 먹","약을 먹","약 복용","약을 복용","투약"
        };
        for(String k:hard)if(x.contains(k))return true;
        return x.matches(".*(^|[ ,.!?])약(을|이|은|도|만|부터|까지)?[ ,.!?].*");
    }
}
