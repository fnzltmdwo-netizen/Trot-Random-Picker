package com.mandarin.chiyeonwidget;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public final class GptMasterStore {
    private static final String FILE = "gpt_master_conversation.txt";
    private GptMasterStore() {}

    public static void save(Context c, String text) throws Exception {
        File f = new File(c.getFilesDir(), FILE);
        try (FileOutputStream out = new FileOutputStream(f, false)) {
            out.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
        }
    }

    public static String read(Context c) throws Exception {
        File f = new File(c.getFilesDir(), FILE);
        if (!f.exists()) return "";
        byte[] data = new byte[(int) f.length()];
        try (FileInputStream in = new FileInputStream(f)) {
            int off = 0, n;
            while (off < data.length && (n = in.read(data, off, data.length - off)) > 0) off += n;
        }
        return new String(data, StandardCharsets.UTF_8);
    }

    public static int chars(Context c) {
        File f = new File(c.getFilesDir(), FILE);
        if (!f.exists()) return 0;
        try { return read(c).length(); } catch (Exception e) { return 0; }
    }
}
