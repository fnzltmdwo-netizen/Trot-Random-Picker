package com.mandarin.chiyeonwidget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Foreground worker for rebuilding the MaeumMon-style importance TOP8.
 * It deliberately lives outside MainActivity so leaving the screen does not cancel the API call.
 */
public class ImportanceAnalysisService extends Service {
    public static final String ACTION_REBUILD = "com.mandarin.chiyeonwidget.ACTION_REBUILD_IMPORTANCE";
    private static final String CHANNEL_ID = "chiyeon_importance_analysis";
    private static final int NOTIFICATION_ID = 1401;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean running = false;

    @Override public void onCreate() {
        super.onCreate();
        ensureChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_NOT_STICKY;
        if (intent == null || !ACTION_REBUILD.equals(intent.getAction())) return START_NOT_STICKY;

        running = true;
        Prefs.setImportanceRunning(this, true, "MASTER 중요 이야기 TOP8 분석 준비 중…");
        startForeground(NOTIFICATION_ID, notification("MASTER 중요 이야기 TOP8 분석 중…"));

        executor.execute(() -> runRebuild(startId));
        return START_NOT_STICKY;
    }

    private void runRebuild(int startId) {
        try {
            String key = Prefs.apiKey(this);
            if (key == null || key.trim().isEmpty()) throw new IllegalStateException("OpenAI API Key가 없어.");

            String full = GptMasterStore.read(this);
            if (full == null || full.trim().length() < 500) {
                throw new IllegalStateException("저장된 GPT MASTER가 없어.");
            }

            Prefs.setImportanceRunning(this, true,
                    "MASTER " + full.length() + "자 유지 · FAST 중요도 분석 중…");
            updateNotification("MASTER " + full.length() + "자 · 중요 TOP8 고르는 중…");

            OpenAiDirectClient.AnalyzeResult result =
                    OpenAiDirectClient.analyzePersonalConversation(key, full);

            // Only replace the importance/context layer. MASTER text + metadata remain untouched.
            Prefs.saveStyle(this, result.styleProfile, result.sourceChars,
                    result.userContext, result.contextItems);

            TimeMood mood = TimeMood.current();
            int rotation = Prefs.nextContextRotation(this);
            ContextRotation.Selection selected = ContextRotation.choose(
                    result.userContext, Prefs.masterLast(this), rotation);
            String quote = OpenAiDirectClient.generateComfort(
                    key, result.styleProfile, selected.context, selected.anchor, mood);
            Prefs.saveMood(this, mood);
            Prefs.saveQuote(this, quote);
            Prefs.bumpVisualRevision(this);
            ChiyeonWidgetProvider.updateAll(this);

            Prefs.finishImportanceAnalysis(this, true,
                    "✅ 중요 이야기 TOP" + result.contextItems + " 선정 완료 · MASTER " + result.sourceChars + "자 유지");
            showCompletionNotification("중요 이야기 TOP" + result.contextItems + " 선정 완료");
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg == null || msg.trim().isEmpty()) msg = e.getClass().getSimpleName();
            if (msg.length() > 180) msg = msg.substring(0, 180) + "…";
            Prefs.finishImportanceAnalysis(this, false, "⚠️ 중요도 분석 실패 · " + msg);
            showCompletionNotification("중요도 분석 실패");
        } finally {
            running = false;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelfResult(startId);
        }
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "치연 중요 이야기 분석", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("중요 이야기 TOP8을 백그라운드에서 고르는 동안 표시됩니다.");
            nm.createNotificationChannel(ch);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1401, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setSmallIcon(R.drawable.app_icon)
                .setContentTitle("치연이 중요 이야기를 고르는 중")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, notification(text));
    }

    private void showCompletionNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1402, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Notification n = b.setSmallIcon(R.drawable.app_icon)
                .setContentTitle("치연 중요 이야기 분석")
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID + 1, n);
    }

    @Override public void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
