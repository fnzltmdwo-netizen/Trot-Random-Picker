package com.mandarin.chiyeonwidget;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.content.Intent;
import android.os.Handler;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ChatGptCaptureAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler();
    private boolean running = false;
    private boolean scheduled = false;
    private int stable = 0;
    private int steps = 0;
    private String lastSignature = "";
    private final ArrayList<String> masterLines = new ArrayList<>();

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!Prefs.mobileCaptureActive(this)) return;
        CharSequence pkg = event == null ? null : event.getPackageName();
        if (pkg == null || !"com.openai.chatgpt".contentEquals(pkg)) return;
        if (!running) {
            running = true;
            stable = 0;
            steps = 0;
            lastSignature = "";
            masterLines.clear();
            Toast.makeText(this, "치연: 마지막 대화부터 시작해서 맨 처음까지 한 번만 훑을게.", Toast.LENGTH_SHORT).show();
        }
        scheduleStep(350);
    }

    @Override public void onInterrupt() {}

    private void scheduleStep(long delay) {
        if (scheduled || !running) return;
        scheduled = true;
        handler.postDelayed(() -> {
            scheduled = false;
            step();
        }, delay);
    }

    private void step() {
        if (!running || !Prefs.mobileCaptureActive(this)) {
            running = false;
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            scheduleStep(500);
            return;
        }

        AccessibilityNodeInfo scroll = findBestScrollable(root);
        List<String> visible = visibleLines(root);
        String sig = signature(visible);

        // v1.3.9.3: ChatGPT normally opens at the newest/bottom of a conversation.
        // Collect while moving upward only once. Each earlier screen is prepended,
        // so the stored MASTER still ends up in chronological top→bottom order.
        prependScreen(visible);

        if (sig.equals(lastSignature)) stable++; else stable = 0;
        lastSignature = sig;

        boolean moved = scroll != null && scroll.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        steps++;

        if ((!moved && stable >= 2) || stable >= 7 || steps >= 1200) {
            finishCapture();
        } else {
            scheduleStep(600);
        }
    }

    private void finishCapture() {
        running = false;
        Prefs.setMobileCaptureActive(this, false);

        StringBuilder b = new StringBuilder();
        for (String line : masterLines) {
            if (b.length() > 0) b.append('\n');
            b.append(line);
        }
        String text = b.toString().trim();
        if (text.length() < 500) {
            Prefs.saveMobileCaptureResult(this, false, text.length(), "", "");
            Toast.makeText(this, "치연: 대화를 충분히 못 읽었어. 채팅 화면에서 다시 시도해줘.", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            int appliedChars = Prefs.sourceChars(this);
            if (appliedChars >= 20000 && text.length() < appliedChars * 0.85) {
                Prefs.saveMobileCaptureResult(this, false, text.length(), "", "");
                Toast.makeText(this,
                        "치연: 새 수집 " + text.length() + "자는 기존 MASTER " + appliedChars
                                + "자보다 너무 짧아서 버렸어. 기존 개인화는 그대로야.",
                        Toast.LENGTH_LONG).show();

                Intent back = new Intent(this, MainActivity.class);
                back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(back);
                return;
            }

            GptMasterStore.save(this, text);
            String first = preview(masterLines.isEmpty() ? "" : masterLines.get(0));
            String last = preview(masterLines.isEmpty() ? "" : masterLines.get(masterLines.size() - 1));
            Prefs.saveMobileCaptureResult(this, true, text.length(), first, last);
            Toast.makeText(this,
                    "치연: 전체수집 완료 · " + text.length() + "자! 이제 치연에 반영할게.",
                    Toast.LENGTH_LONG).show();

            // Always bring the app back so the saved capture cannot sit unnoticed.
            Intent back = new Intent(this, MainActivity.class);
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(back);
        } catch (Exception e) {
            Prefs.saveMobileCaptureResult(this, false, 0, "", "");
            Toast.makeText(this, "치연: MASTER 저장에 실패했어.", Toast.LENGTH_LONG).show();
        }
    }

    private AccessibilityNodeInfo findBestScrollable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        AccessibilityNodeInfo best = null;
        long bestArea = -1;
        ArrayList<AccessibilityNodeInfo> stack = new ArrayList<>();
        stack.add(node);
        while (!stack.isEmpty()) {
            AccessibilityNodeInfo n = stack.remove(stack.size() - 1);
            if (n == null) continue;
            if (n.isScrollable()) {
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                long area = Math.max(0, r.width()) * (long)Math.max(0, r.height());
                if (area > bestArea) {
                    bestArea = area;
                    best = n;
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) stack.add(c);
            }
        }
        return best;
    }

    private List<String> visibleLines(AccessibilityNodeInfo root) {
        ArrayList<String> out = new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> stack = new ArrayList<>();
        stack.add(root);
        String last = "";
        while (!stack.isEmpty()) {
            AccessibilityNodeInfo n = stack.remove(stack.size() - 1);
            if (n == null) continue;

            CharSequence t = n.getText();
            if (t != null) {
                String s = clean(t.toString());
                if (keep(s) && !s.equals(last)) {
                    out.add(s);
                    last = s;
                }
            }
            CharSequence d = n.getContentDescription();
            if (d != null && (t == null || !d.toString().equals(t.toString()))) {
                String s = clean(d.toString());
                if (keep(s) && !s.equals(last)) {
                    out.add(s);
                    last = s;
                }
            }

            // Push in reverse so traversal keeps visual-ish child order.
            for (int i = n.getChildCount() - 1; i >= 0; i--) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) stack.add(c);
            }
        }
        return out;
    }

    private boolean keep(String s) {
        if (s == null || s.isEmpty()) return false;
        String x = s.toLowerCase(Locale.ROOT);
        if (x.equals("chatgpt") || x.equals("메시지 보내기") || x.equals("send message")) return false;
        if (x.equals("복사") || x.equals("copy") || x.equals("좋아요") || x.equals("싫어요")) return false;
        if (x.startsWith("새 채팅") || x.startsWith("new chat")) return false;
        return true;
    }

    private String clean(String s) {
        return s.replace('\u00a0', ' ')
                .replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\n\n")
                .trim();
    }

    private String signature(List<String> lines) {
        StringBuilder b = new StringBuilder();
        int start = Math.max(0, lines.size() - 10);
        for (int i = start; i < lines.size(); i++) b.append(lines.get(i)).append('|');
        return Integer.toHexString(b.toString().hashCode()) + ":" + b.length();
    }

    private void prependScreen(List<String> screen) {
        if (screen == null || screen.isEmpty()) return;
        if (masterLines.isEmpty()) {
            masterLines.addAll(screen);
            return;
        }

        // Earlier screen: [A,B,C,D], existing later master: [C,D,E,F].
        // Find suffix(screen) == prefix(master), then prepend only [A,B].
        int max = Math.min(Math.min(masterLines.size(), screen.size()), 40);
        int overlap = 0;
        for (int k = max; k >= 1; k--) {
            boolean same = true;
            for (int j = 0; j < k; j++) {
                if (!screen.get(screen.size() - k + j).equals(masterLines.get(j))) {
                    same = false;
                    break;
                }
            }
            if (same) {
                overlap = k;
                break;
            }
        }

        ArrayList<String> prefix = new ArrayList<>();
        for (int i = 0; i < screen.size() - overlap; i++) {
            String line = screen.get(i);
            if (!line.isEmpty()) prefix.add(line);
        }
        if (!prefix.isEmpty()) masterLines.addAll(0, prefix);
    }

    private String preview(String s) {
        String x = clean(s).replace('\n', ' ');
        return x.length() <= 120 ? x : x.substring(0, 119).trim() + "…";
    }
}
