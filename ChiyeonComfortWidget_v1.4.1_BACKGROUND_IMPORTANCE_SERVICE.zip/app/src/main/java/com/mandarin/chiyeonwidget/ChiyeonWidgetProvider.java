package com.mandarin.chiyeonwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver.PendingResult;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChiyeonWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.mandarin.chiyeonwidget.ACTION_REFRESH";
    public static final String ACTION_AUTO_MOOD = "com.mandarin.chiyeonwidget.ACTION_AUTO_MOOD";
    public static final String EXTRA_WIDGET_ID = "widget_id";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        TimeMood mood = TimeMood.current();
        if (Prefs.isMoodChanged(context, mood)) {
            Prefs.saveMood(context, mood);
            if (Prefs.apiKey(context).trim().isEmpty()) {
                Prefs.saveQuote(context, LocalComfortBank.pick(mood));
            }
            Prefs.bumpVisualRevision(context);
        }
        updateAll(context);
        WidgetScheduler.scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        WidgetScheduler.cancel(context);
        super.onDisabled(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        TimeMood mood = TimeMood.current();
        if (Prefs.isMoodChanged(context, mood)) {
            Prefs.saveMood(context, mood);
            if (Prefs.apiKey(context).trim().isEmpty()) {
                Prefs.saveQuote(context, LocalComfortBank.pick(mood));
            }
            Prefs.bumpVisualRevision(context);
        }
        for (int id : appWidgetIds) updateWidget(context, appWidgetManager, id, mood);
        WidgetScheduler.scheduleNext(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (ACTION_REFRESH.equals(action) || ACTION_AUTO_MOOD.equals(action)) {
            TimeMood mood = TimeMood.current();
            Prefs.saveMood(context, mood);
            Prefs.bumpVisualRevision(context);
            updateAll(context);
            WidgetScheduler.scheduleNext(context);
            if (Prefs.apiKey(context).trim().isEmpty()) {
                Prefs.saveQuote(context, LocalComfortBank.pick(mood));
                updateAll(context);
            } else {
                requestAiRefresh(context, mood);
            }
            return;
        }

        if (Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                || Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            TimeMood mood = TimeMood.current();
            boolean changed = Prefs.isMoodChanged(context, mood);
            if (changed) {
                Prefs.saveMood(context, mood);
                if (Prefs.apiKey(context).trim().isEmpty()) {
                    Prefs.saveQuote(context, LocalComfortBank.pick(mood));
                }
                Prefs.bumpVisualRevision(context);
                updateAll(context);
            }
            WidgetScheduler.scheduleNext(context);
            if (changed && !Intent.ACTION_BOOT_COMPLETED.equals(action)) requestAiRefresh(context, mood);
            return;
        }
        super.onReceive(context, intent);
    }

    private void requestAiRefresh(Context context, TimeMood requestedMood) {
        String key = Prefs.apiKey(context);
        if (key.trim().isEmpty()) return;
        PendingResult pending = goAsync();
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                int rotation = Prefs.nextContextRotation(appContext);
                ContextRotation.Selection selected = ContextRotation.choose(
                        Prefs.userContext(appContext), Prefs.masterLast(appContext), rotation);
                String ai = OpenAiDirectClient.generateComfort(
                        key, Prefs.styleProfile(appContext), selected.context,
                        selected.anchor, requestedMood);
                if (TimeMood.current() == requestedMood) {
                    Prefs.saveQuote(appContext, ai);
                    updateAll(appContext);
                }
            } catch (Exception ignored) {
            } finally {
                pending.finish();
            }
        });
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, ChiyeonWidgetProvider.class));
        TimeMood mood = TimeMood.current();
        for (int id : ids) updateWidget(context, manager, id, mood);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int appWidgetId, TimeMood mood) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_chiyeon);
        WidgetVisuals.Spec theme = WidgetVisuals.forMood(mood);
        int seed = WidgetVisuals.seed(context, mood);

        views.setTextViewText(R.id.widget_quote, Prefs.quote(context));
        views.setTextViewText(R.id.widget_comfort_title, mood.label() + " · 치연의 위로");
        views.setTextViewText(R.id.widget_mood_clock_label, mood.clockLabel());
        views.setTextColor(R.id.widget_mood_clock_label, theme.titleColor);
        views.setTextColor(R.id.widget_comfort_title, theme.titleColor);
        views.setTextColor(R.id.widget_quote, theme.quoteColor);
        views.setInt(R.id.widget_quote, "setBackgroundResource", theme.bubbleRes);
        views.setImageViewResource(R.id.widget_scrim, theme.scrimRes);
        views.setImageViewResource(R.id.widget_chiyeon, WidgetVisuals.pick(theme.characters, seed));
        views.setImageViewResource(R.id.widget_bg, WidgetVisuals.pick(theme.backgrounds, seed * 31 + 17));

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(context, appWidgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openPi);

        Intent refresh = new Intent(context, ChiyeonWidgetProvider.class);
        refresh.setAction(ACTION_REFRESH);
        refresh.putExtra(EXTRA_WIDGET_ID, appWidgetId);
        PendingIntent refreshPi = PendingIntent.getBroadcast(context, 10_000 + appWidgetId, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPi);
        views.setOnClickPendingIntent(R.id.widget_quote, refreshPi);

        manager.updateAppWidget(appWidgetId, views);
    }
}
