package com.mandarin.chiyeonwidget;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;
import java.util.LinkedHashSet;

public class FullConversationCollectorActivity extends Activity {
    public static final String EXTRA_URL="url";
    public static final String EXTRA_TEXT="full_text";
    public static final String EXTRA_PREVIOUS_CHARS="previous_chars";
    private WebView web;
    private TextView status, detail;
    private final Handler h=new Handler();
    private final LinkedHashSet<String> turns=new LinkedHashSet<>();
    private int stable=0, passes=0, lastCount=0;
    private long started;
    private int previousChars;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_full_collector);
        status=findViewById(R.id.collectStatus);
        previousChars=getIntent().getIntExtra(EXTRA_PREVIOUS_CHARS,0);
        detail=findViewById(R.id.collectDetail);
        web=findViewById(R.id.collectWeb);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(),"ChiyeonBridge");
        String url=getIntent().getStringExtra(EXTRA_URL);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String u){
                status.setText("전체 대화 수집 시작 · 0턴 · 0자");
                detail.setText("처음부터 끝까지 내려가며 새 발화를 모으는 중…");
                started=System.currentTimeMillis();
                h.postDelayed(()->scan(true),1200);
            }
        });
        web.loadUrl(url);
    }
    private void scan(boolean first){
        if(first) {
            String init="(function(){function pick(){var c=[];if(document.scrollingElement)c.push(document.scrollingElement);"
                +"var a=document.querySelectorAll('main,section,div');for(var i=0;i<a.length;i++)c.push(a[i]);var best=null,score=-1;"
                +"for(var j=0;j<c.length;j++){var e=c[j],ch=e.clientHeight||0,sh=e.scrollHeight||0;if(ch<220||sh-ch<180)continue;"
                +"var sc=(sh-ch)*10+sh;if(sc>score){score=sc;best=e;}}window.__chiRoot=best||document.scrollingElement||document.documentElement||document.body;"
                +"window.__chiRoot.scrollTop=0;window.scrollTo(0,0);return true;})()";
            web.evaluateJavascript(init,x->h.postDelayed(()->scan(false),650));
            return;
        }
        String js="(function(){"
            +"function add(arr,seen,r,t){t=((t||'')+'').trim();if(t.length<2)return;var k=r+'|'+t;if(seen[k])return;seen[k]=1;arr.push(r+'\\n'+t);}"
            +"var blocks=[],seen={};var n=document.querySelectorAll('[data-message-author-role]');"
            +"for(var i=0;i<n.length;i++)add(blocks,seen,n[i].getAttribute('data-message-author-role')||'message',n[i].innerText||n[i].textContent||'');"
            +"var ts=document.querySelectorAll('[data-testid^=conversation-turn],[data-testid*=conversation-turn]');for(var j=0;j<ts.length;j++){if(ts[j].querySelector('[data-message-author-role]'))continue;add(blocks,seen,'turn',ts[j].innerText||ts[j].textContent||'');}"
            +"try{var jsn=document.querySelectorAll('script[type*=json]');for(var q=0;q<jsn.length;q++){try{var o=JSON.parse(jsn[q].textContent||'{}');"
            +"(function walk(x,d){if(!x||d>18)return;if(Array.isArray(x)){for(var ai=0;ai<x.length;ai++)walk(x[ai],d+1);return;}if(typeof x!=='object')return;"
            +"var r='';try{r=(x.author&&x.author.role)||x.role||'';}catch(e){}var t='';try{if(x.content&&Array.isArray(x.content.parts))t=x.content.parts.filter(function(v){return typeof v==='string';}).join('\\n');else if(typeof x.content==='string')t=x.content;else if(typeof x.text==='string')t=x.text;}catch(e){}"
            +"if((r==='user'||r==='assistant')&&t)add(blocks,seen,r,t);for(var k in x)if(Object.prototype.hasOwnProperty.call(x,k))walk(x[k],d+1);})(o,0);}catch(e){}}}catch(e){}"
            +"try{var els=[].slice.call(document.querySelectorAll('button,[role=button]'));for(var e=0;e<els.length;e++){var z=((els[e].innerText||'')+'').trim();if(/^(더 보기|더보기|계속 보기|계속 읽기|Show more|Continue reading)$/i.test(z))try{els[e].click();}catch(x){}}}catch(e){}"
            +"var root=window.__chiRoot;if(!root||!root.isConnected)root=document.scrollingElement||document.documentElement||document.body;"
            +"var top=root.scrollTop||0,client=root.clientHeight||0,scroll=root.scrollHeight||0,max=Math.max(0,scroll-client);"
            +"try{ChiyeonBridge.frame(blocks.join('\\n␞\\n'),top,max);}catch(e){}"
            +"var step=Math.max(420,Math.floor((client||window.innerHeight||800)*.70));if(max>120){root.scrollTop=Math.min(max,top+step);root.dispatchEvent(new Event('scroll',{bubbles:true}));}window.scrollBy(0,step);"
            +"return blocks.length;})()";
        web.evaluateJavascript(js,null);
    }
    final class Bridge{
        @JavascriptInterface public void frame(String text,double top,double max){
            h.post(()->{
                if(text!=null&&!text.trim().isEmpty()){
                    for(String x:text.split("␞")){String q=x.trim();if(q.length()>2)turns.add(q);}
                }
                passes++;
                if(turns.size()==lastCount)stable++;else stable=0;
                lastCount=turns.size();
                int chars=build().length();
                status.setText("수집 중 · "+turns.size()+"턴 · "+chars+"자");
                int pct = max <= 20 ? 100 : (int)Math.max(0, Math.min(100, Math.round((top / max) * 100.0)));
                detail.setText("진행 "+pct+"% · 끝까지 확인 중 · 중복 발화 자동 제외");
                boolean bottom=max<=20 || top>=max-30;
                if((bottom&&stable>=8&&passes>=12)||(System.currentTimeMillis()-started>300000)){
                    finishOk();
                } else h.postDelayed(()->scan(false),450);
            });
        }
    }
    private String build(){
        StringBuilder b=new StringBuilder();
        for(String x:turns){if(b.length()>0)b.append("\n\n");b.append(x);}
        return b.toString();
    }
    private void finishOk(){
        String text=build();
        if(text.length()<800){Toast.makeText(this,"전체 대화를 충분히 읽지 못했어.",Toast.LENGTH_LONG).show();finish();return;}
        if(previousChars >= 20000 && text.length() < previousChars * 0.60){
            status.setText("⚠️ 불완전 수집 감지 · "+text.length()+"자");
            detail.setText("이전 학습 "+previousChars+"자보다 너무 적어서 기존 MASTER를 보호했어. 다시 시도해줘.");
            h.postDelayed(this::finish,1800);
            return;
        }
        status.setText("✅ 전체수집 완료 · "+turns.size()+"턴 · "+text.length()+"자");
        detail.setText("MASTER 원문 생성 완료 · 치연 말투 + 내 이야기 분석으로 넘어갈게.");
        Intent i=new Intent();i.putExtra(EXTRA_TEXT,text);setResult(RESULT_OK,i);
        h.postDelayed(this::finish, 650);
    }
}