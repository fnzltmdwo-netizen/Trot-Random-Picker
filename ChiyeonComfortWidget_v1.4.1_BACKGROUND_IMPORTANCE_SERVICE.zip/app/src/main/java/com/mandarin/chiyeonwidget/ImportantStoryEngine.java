package com.mandarin.chiyeonwidget;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/**
 * Chiyeon importance ranking, adapted from MaeumMon counseling concepts:
 * current concern / repeated flow / turning point / change goal +
 * recency / repetition / burden / direction-change / novelty / ongoing.
 *
 * This class does NOT diagnose or formulate therapy. It only ranks which
 * user-stated story is most worth referencing in a small widget.
 */
public final class ImportantStoryEngine {
    private ImportantStoryEngine() {}

    public static final class Story {
        public String topic="", fact="", concern="", flow="", turning="", goal="";
        public int recency, repetition, burden, direction, novelty, ongoing;
        public int score;

        public String render() {
            StringBuilder b=new StringBuilder();
            b.append("[중요도 ").append(score).append("] ").append(topic);
            if(!fact.isEmpty()) b.append(" · 최근 사실: ").append(fact);
            if(!concern.isEmpty()) b.append(" · 지금 고민: ").append(concern);
            if(!flow.isEmpty()) b.append(" · 반복 흐름: ").append(flow);
            if(!turning.isEmpty()) b.append(" · 최근 전환: ").append(turning);
            if(!goal.isEmpty()) b.append(" · 지금 원하는 변화: ").append(goal);
            return b.toString();
        }
    }

    public static String rankTop8(String raw) {
        List<Story> all=parse(raw);
        LinkedHashMap<String,Story> dedup=new LinkedHashMap<>();

        for(Story s:all){
            if(ContextRotation.isMedicalTopic(s.topic+" "+s.fact+" "+s.concern+" "+s.flow+" "+s.turning+" "+s.goal))
                continue;
            String k=key(s.topic.isEmpty()?s.concern:s.topic);
            if(k.isEmpty()) continue;
            s.score=score(s);
            Story old=dedup.get(k);
            if(old==null || s.score>old.score) dedup.put(k,s);
        }

        List<Story> ranked=new ArrayList<>(dedup.values());
        Collections.sort(ranked,new Comparator<Story>(){
            @Override public int compare(Story a,Story b){ return Integer.compare(b.score,a.score); }
        });

        StringBuilder out=new StringBuilder();
        for(int i=0;i<ranked.size() && i<8;i++){
            if(out.length()>0) out.append('\n');
            out.append(ranked.get(i).render());
        }
        return out.toString();
    }

    private static int score(Story s){
        // MaeumMon-inspired priorities, simplified for a casual widget.
        // Recency and repetition matter most; unresolved/ongoing and burden keep
        // an active topic alive; turning/direction/novelty surface meaningful changes.
        double v =
                s.recency    * 0.24 +
                s.repetition * 0.20 +
                s.burden     * 0.17 +
                s.ongoing    * 0.16 +
                turningSignal(s) * 0.09 +
                s.direction  * 0.08 +
                s.novelty    * 0.06;
        return clamp((int)Math.round(v));
    }

    private static int turningSignal(Story s){
        if(!s.turning.trim().isEmpty()) return 100;
        return Math.max(s.direction,s.novelty);
    }

    private static List<Story> parse(String raw){
        List<Story> out=new ArrayList<>();
        if(raw==null)return out;
        for(String line:raw.split("\\n")){
            String x=line.trim();
            if(x.isEmpty()||!x.startsWith("STORY||"))continue;
            String[] a=x.split("\\|\\|",-1);
            if(a.length<13)continue;
            Story s=new Story();
            s.topic=clean(a[1]); s.fact=clean(a[2]); s.concern=clean(a[3]);
            s.flow=clean(a[4]); s.turning=clean(a[5]); s.goal=clean(a[6]);
            s.recency=num(a[7]); s.repetition=num(a[8]); s.burden=num(a[9]);
            s.direction=num(a[10]); s.novelty=num(a[11]); s.ongoing=num(a[12]);
            out.add(s);
        }
        return out;
    }

    private static int num(String x){
        try{return clamp(Integer.parseInt(x.trim()));}catch(Exception e){return 0;}
    }
    private static int clamp(int v){return Math.max(0,Math.min(100,v));}
    private static String clean(String s){return s==null?"":s.trim().replace('\n',' ');}
    private static String key(String s){
        if(s==null)return "";
        return s.toLowerCase(Locale.KOREA).replaceAll("[^0-9a-z가-힣]","")
                .replace("연습","").replace("문제","").replace("고민","").trim();
    }
}
