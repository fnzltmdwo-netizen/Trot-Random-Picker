package com.mandarin.chiyeonwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class WidgetScheduler {
    private static final int REQUEST_CODE = 4421;

    private WidgetScheduler() {}

    public static void scheduleNext(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        alarm.cancel(pending(context));

        // This visual change does not need to wake a sleeping phone. Use a small inexact window
        // instead of requesting exact-alarm special access. The 30-minute AppWidget update is a safety net.
        alarm.setWindow(
                AlarmManager.RTC,
                TimeMood.nextBoundaryMillis(),
                10 * 60 * 1000L,
                pending(context)
        );
    }

    public static void cancel(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(pending(context));
    }

    private static PendingIntent pending(Context context) {
        Intent intent = new Intent(context, ChiyeonWidgetProvider.class);
        intent.setAction(ChiyeonWidgetProvider.ACTION_AUTO_MOOD);
        return PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }
}
