package com.mandarin.chiyeonwidget;

import android.text.Html;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class OpenAiDirectClient {
    private OpenAiDirectClient() {}

    private static final String RESPONSES_URL = "https://api.openai.com/v1/responses";
    private static final String MODEL = "gpt-5.6-luna";

    public static final class AnalyzeResult {
        public final String styleProfile;
        public final int sourceChars;
        public final String sourceMode;
        public final String userContext;
        public final int contextItems;

        AnalyzeResult(String styleProfile, int sourceChars, String sourceMode, String userContext, int contextItems) {
            this.styleProfile = styleProfile;
            this.sourceChars = sourceChars;
            this.sourceMode = sourceMode;
            this.userContext = userContext == null ? "" : userContext;
            this.contextItems = contextItems;
        }
    }

    public static AnalyzeResult analyzeShare(String apiKey, String shareUrl) throws Exception {
        requireKey(apiKey);
        validateShareUrl(shareUrl);
        String html = getHtml(shareUrl.trim());
        String text = extractReadableText(html);
        return analyzeFullText(apiKey, text);
    }

    public static AnalyzeResult analyzeFullText(String apiKey, String text) throws Exception {
        requireKey(apiKey);
        text = clean(text == null ? "" : text);
        if (text.length() < 800) {
            throw new IllegalStateException("공유페이지에서 충분한 원문을 읽지 못했어.");
        }
        List<String> parts = chunks(text, 12000);
        StringBuilder evidence = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            String prompt = "너는 캐릭터 말투 분석가다. 아래 긴 대화/대본의 " + (i + 1) + "/" + parts.size() + " 구간을 분석한다.\n"
                    + "목표는 김치연(치연)의 말투 재현이며 줄거리 요약이 아니다. 자동 자막이라 이름 오기가 있을 수 있다. "
                    + "치연의 직접 발화에 가장 높은 가중치를 둔다. 욕설·모욕·외모/나이/성별 고정관념은 위로에서 제거 대상으로 표시한다.\n\n"
                    + "추출: 1) 시작 감탄사/접속어 2) 문장 길이와 리듬 3) 종결어미/질문/반복 4) 감정표현 "
                    + "5) 친근함/직설성/과장 6) 위로에 살릴 말맛 7) 제거할 독한 요소 8) 짧은 패턴 5개.\n\n[원문]\n"
                    + parts.get(i);
            evidence.append("\n--- 구간 ").append(i + 1).append(" ---\n")
                    .append(call(apiKey, prompt));
        }

        String mergePrompt = "아래는 전체 원문을 여러 구간으로 분석한 증거다. 고정된 치연 말투 DNA를 훼손하지 말고 세부 어휘/리듬을 보강하는 보조 프로필을 작성해.\n"
                + ChiyeonSpeechDna.PROFILE + "\n"
                + "치연 특유의 즉각적인 감탄, 짧고 직설적인 구어체, 진짜/그냥/됐어/뭐 어때/그래 류의 리듬은 살리고, "
                + "욕설·모욕·외모/나이/성별 비교·연애/결혼 압박·과소비 조장은 제거한다. 단순한 상담사 말투가 아니라 친한 치연이 옆에서 툭 말하는 느낌이어야 한다. "
                + "실제 위젯 문장은 1~2문장, 18~60자를 기본으로 한다.\n\n"
                + "형식: [핵심 캐릭터] [말버릇/어휘] [문장 리듬] [감정 표현] [위로 전환 규칙] [금지 요소] [생성 템플릿 8개] [새 예시 12개]\n\n"
                + evidence;
        String profile = call(apiKey, mergePrompt);

        // v1.3.3: learn WHAT the user has been talking about separately from HOW Chiyeon talks.
        // Recent chunks are weighted most heavily so widget lines can refer to current context
        // without sending the entire source transcript on every refresh.
        int contextStart = Math.max(0, parts.size() - 12);
        StringBuilder contextEvidence = new StringBuilder();
        for (int i = contextStart; i < parts.size(); i++) {
            String contextPrompt = "아래 ChatGPT 대화 구간에서 '사용자 본인이 말한 현재 이야기'만 추출해. "
                    + "치연/캐릭터 말투 분석은 하지 마. 사용자가 직접 말한 사실, 최근 사건, 하고 있는 일, 고민, 계획, "
                    + "선호, 방금 겪은 문제를 최대 8개 짧은 항목으로 적어. 추측하거나 진단하지 말고, 오래된 내용보다 최근 내용을 우선해. "
                    + "민감한 개인정보는 위젯 문구에 그대로 노출하지 않도록 일반화해서 적어.\\n\\n[대화]\\n" + parts.get(i);
            contextEvidence.append("\\n--- 최근 맥락 ").append(i + 1).append(" ---\\n")
                    .append(call(apiKey, contextPrompt));
        }
        String contextMergePrompt = "다음은 사용자의 최근 대화에서 추출한 맥락 후보야. 중복을 합치고 최근성을 우선해서 "
                + "위젯 대사 생성에 참고할 '최근 사용자 맥락'을 최대 20개 항목으로 만들어. "
                + "각 항목은 한 줄, 구체적이되 위젯에 민감한 개인정보를 직접 노출하지 않게 표현해. "
                + "없는 사실은 만들지 마.\\n\\n" + contextEvidence;
        String userContext = call(apiKey, contextMergePrompt).trim();
        int contextItems = 0;
        for (String line : userContext.split("\\n")) {
            String q = line.trim();
            if (!q.isEmpty() && !q.startsWith("[") && contextItems < 20) contextItems++;
        }
        return new AnalyzeResult(profile, text.length(), "full_share_master", userContext, contextItems);
    }

    public static AnalyzeResult analyzePersonalConversation(String apiKey, String text) throws Exception {
        requireKey(apiKey);
        text = clean(text == null ? "" : text);
        if (text.length() < 200) {
            throw new IllegalStateException("가져온 GPT 대화 원문이 너무 짧아.");
        }

        /*
         * v1.4.0 FAST IMPORTANCE
         * MASTER 전체는 로컬에 100% 보관하지만 중요도 재분석은 보통 API 1회로 끝낸다.
         *
         * 입력 압축:
         * - 최근 48,000자: 그대로 포함 (현재 고민/진행중/전환점 우선)
         * - 오래된 영역: 전체 기간을 대표하는 6,000자 샘플 3개
         *   (초반 / 중간 / 최근 직전)
         *
         * 모델은 STORY 후보와 각 중요도 근거 점수를 한 번에 반환하고,
         * 최종 가중치 계산/중복제거/TOP8 정렬은 ImportantStoryEngine이 로컬에서 한다.
         */
        final int recentMax = 48000;
        final int historySampleSize = 6000;
        final int historySamples = 3;

        int recentStart = Math.max(0, text.length() - recentMax);
        String history = text.substring(0, recentStart);
        String recent = text.substring(recentStart);

        StringBuilder compact = new StringBuilder();

        if (!history.trim().isEmpty()) {
            int maxStart = Math.max(0, history.length() - historySampleSize);
            for (int i = 0; i < historySamples; i++) {
                int pos = historySamples <= 1
                        ? 0
                        : (int)Math.round(maxStart * (i / (double)(historySamples - 1)));
                int end = Math.min(history.length(), pos + historySampleSize);
                compact.append("\n\n[과거 대표 구간 ").append(i + 1).append("]\n")
                        .append(history.substring(pos, end));
            }
        }

        compact.append("\n\n[최근 상세 구간 — 최우선]\n").append(recent);

        String prompt =
                "아래는 사용자의 GPT MASTER 전체에서 빠르게 뽑은 '과거 대표 구간 + 최근 상세 구간'이다. "
              + "마음몬 상담에서 쓰던 중요도 판단 개념을 오직 '어떤 이야기를 치연 위젯이 기억할 가치가 큰가'를 고르는 데만 사용해. "
              + "진단이나 치료 계획을 만들지 마.\n\n"
              + "중요도 판단 기준:\n"
              + "1) 최근성: 최근에도 다시 나온 이야기인가\n"
              + "2) 반복성: 여러 시점/여러 상황에서 반복됐는가\n"
              + "3) 부담도: 사용자가 실제로 크게 신경 쓰거나 힘들다고 말했는가\n"
              + "4) 진행중: 아직 끝나지 않았거나 현재 행동/결정이 이어지고 있는가\n"
              + "5) 전환점: 최근 생각/상황/관계/방향이 바뀐 핵심 변화가 있었는가\n"
              + "6) 방향변화: 이전과 다른 선택/태도/목표가 생겼는가\n"
              + "7) 새로움: 최근 새로 생긴 중요한 사실인가\n\n"
              + "각 이야기 후보에는 마음몬식으로 다음을 짧게 구분해:\n"
              + "- 주제\n- 최근 확인된 사실\n- 지금 핵심 고민(current concern)\n"
              + "- 반복되는 흐름(repeated flow)\n- 최근 전환점(turning point)\n"
              + "- 지금 원하는 변화/방향(change goal)\n"
              + "- 최근성/반복성/부담도/방향변화/새로움/진행중 점수(0~100)\n\n"
              + "규칙:\n"
              + "- USER가 직접 말한 사실만 근거로 사용. ASSISTANT의 추측/조언은 사실로 만들지 마.\n"
              + "- 서로 같은 의미의 주제는 하나로 합쳐.\n"
              + "- 최근 정보와 오래된 정보가 충돌하면 최근 정보 우선.\n"
              + "- 이미 명확히 끝난 일회성 잡담은 낮게 평가.\n"
              + "- 약/복용/병원/진료/처방/치료/진단/수술 등 의료·건강 주제는 완전히 제외.\n"
              + "- 최대 16개만 반환.\n"
              + "- 설명/마크다운 없이 아래 STORY 형식만 줄마다 출력.\n\n"
              + "STORY||주제||최근확인사실||지금핵심고민||반복되는흐름||최근전환점(없으면 빈칸)||지금원하는변화||최근성0~100||반복성0~100||부담도0~100||방향변화0~100||새로움0~100||진행중점수0~100\n\n"
              + compact;

        // Normal path: exactly one API call.
        String candidates = call(apiKey, prompt).trim();
        String ranked = ImportantStoryEngine.rankTop8(candidates);

        // Rare format-repair fallback: one extra call only if the structured lines were malformed.
        if (ranked.trim().isEmpty()) {
            String repairPrompt =
                    "아래 응답을 내용 추가 없이 STORY 레코드 형식으로만 고쳐. 최대 8개. "
                  + "약/병원/의료 주제는 제외. 점수는 원문에 있는 값이 없으면 보수적으로 50 이하로 둬.\n"
                  + "형식: STORY||주제||최근확인사실||지금핵심고민||반복되는흐름||최근전환점||지금원하는변화||최근성||반복성||부담도||방향변화||새로움||진행중점수\n\n"
                  + candidates;
            ranked = ImportantStoryEngine.rankTop8(call(apiKey, repairPrompt).trim());
        }

        int contextItems = 0;
        for (String line : ranked.split("\\n")) {
            if (!line.trim().isEmpty()) contextItems++;
        }

        return new AnalyzeResult(
                ChiyeonSpeechDna.PROFILE,
                text.length(),
                "maeummon_fast_importance_top8_v2",
                ranked,
                Math.min(8, contextItems)
        );
    }

    public static String generateComfort(String apiKey, String styleProfile, String userContext,
                                         String recentAnchor, TimeMood mood) throws Exception {
        requireKey(apiKey);

        // PASS 1: decide only WHAT Chiyeon should react to.
        // Do not let the model polish this into counseling prose.
        String contentPrompt =
                "너는 대사 작가의 상황 정리 담당이다. 최종 대사를 쓰지 마.\n"
              + "아래 사용자 맥락에서 지금 위젯 한마디가 반응할 상황 하나만 고른다.\n"
              + "출력은 정확히 3줄만:\n"
              + "상황: 사용자가 실제로 말한 구체 상황 1개\n"
              + "치연의 입장: 그 상황을 보고 치연이 가질 짧고 주관적인 반응\n"
              + "행동: 지금 당장 할 수 있는 행동 또는 결론 1개\n"
              + "심리 진단, 감정 해석, 상담 문장, 위로 문장 금지. 없는 사실 만들지 마.\n\n"
              + "[최근 사용자 맥락]\n" + safePrompt(userContext)
              + "\n\n[가장 최근 GPT 대화]\n" + safePrompt(recentAnchor)
              + "\n\n현재 시간대: " + mood.key() + " / " + mood.promptHint();

        String contentPlan = call(apiKey, contentPrompt).trim();

        // PASS 2: style-only renderer. The semantic plan is fixed; rewrite its surface form as Chiyeon.
        String stylePrompt =
                "너는 지금부터 '치연 말투 렌더러'다. 상담사 역할을 절대 하지 마.\n"
              + "아래 [내용 설계]의 사실과 행동만 사용하고, 표현만 김치연식으로 완전히 다시 써.\n"
              + "최종 출력은 갤럭시 위젯용 대사 딱 하나. 1~3개의 짧은 문장, 보통 18~70자, 최대 95자.\n"
              + "설명, 제목, 따옴표, 화자표시 금지.\n\n"
              + ChiyeonSpeechDna.PROFILE
              + "\n" + ChiyeonSpeechDna.HARD_EXAMPLES
              + "\n[시간대 톤]\n" + ChiyeonSpeechDna.forMood(mood)
              + "\n\n[보조 말투 프로필]\n" + safePrompt(styleProfile)
              + "\n\n[내용 설계 — 내용은 바꾸지 말 것]\n" + contentPlan
              + "\n\n[강제 검사]\n"
              + "- '속상하지/힘들었겠다/그럴 수 있어/천천히/확인해보자/네 편이야/충분히 잘하고 있어'가 들어가면 무조건 다시 작성.\n"
              + "- 첫 문장이 감정 설명이면 다시 작성.\n"
              + "- 최소 하나는 치연식 즉각 반응 또는 주관적 판단이 느껴져야 함.\n"
              + "- 마지막은 행동/결론/툭 끊는 말 중 하나로 끝내.\n"
              + "- 약, 복용, 병원, 진료, 처방, 치료, 진단, 수술 등 의료·건강 이야기는 절대 소재로 쓰지 마.\n"
              + "- 상담사가 아니라 실제 치연 친구가 말하는 것처럼.";

        String message = call(apiKey, stylePrompt).trim().replace('\n', ' ');

        // If the renderer still leaked a counselor phrase, run one hard rewrite pass.
        if (looksTherapistLike(message)) {
            String repairPrompt =
                    "다음 문장은 상담사 말투가 남아 있어 실패했다. 의미는 유지하고 치연 말투로 완전히 갈아엎어.\n"
                  + "공감 설명/심리 해석 전부 삭제. 반응 → 주관적 판단 → 짧은 결론으로 바꿔.\n"
                  + ChiyeonSpeechDna.PROFILE + "\n" + ChiyeonSpeechDna.HARD_EXAMPLES
                  + "\n\n[실패 문장]\n" + message;
            message = call(apiKey, repairPrompt).trim().replace('\n', ' ');
        }

        if (message.startsWith("\"") && message.endsWith("\"") && message.length() > 1) {
            message = message.substring(1, message.length() - 1).trim();
        }
        if (message.length() > 100) message = message.substring(0, 100).trim();
        return message;
    }

    private static String safePrompt(String s) {
        return s == null || s.trim().isEmpty() ? "없음" : s.trim();
    }

    private static boolean looksTherapistLike(String text) {
        if (text == null) return false;
        String x = text.replace(" ", "");
        String[] bad = {
                "속상하지", "힘들었겠다", "그럴수있어", "자연스러운감정",
                "마음을인정", "감정을알아", "천천히", "확인해보자",
                "네편이야", "충분히잘하고", "스스로를믿", "괜찮아질거야"
        };
        for (String b : bad) if (x.contains(b)) return true;
        return false;
    }

    private static String call(String apiKey, String prompt) throws Exception {
        JSONObject req = new JSONObject();
        req.put("model", MODEL);
        req.put("input", prompt);

        HttpURLConnection conn = (HttpURLConnection) new URL(RESPONSES_URL).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(90000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());

        byte[] bytes = req.toString().getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }

        int code = conn.getResponseCode();
        String body = readAll(code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream());
        conn.disconnect();
        if (code < 200 || code >= 300) {
            String detail = body;
            try {
                JSONObject err = new JSONObject(body);
                detail = err.optJSONObject("error") != null ? err.getJSONObject("error").optString("message", body) : body;
            } catch (Exception ignored) {}
            throw new IllegalStateException("OpenAI 오류 " + code + ": " + detail);
        }
        JSONObject obj = new JSONObject(body);
        String out = extractOutputText(obj);
        if (out.trim().isEmpty()) throw new IllegalStateException("OpenAI 응답에 텍스트가 없었어.");
        return out.trim();
    }

    private static String extractOutputText(JSONObject obj) {
        String top = obj.optString("output_text", "");
        if (!top.isEmpty()) return top;
        StringBuilder sb = new StringBuilder();
        JSONArray output = obj.optJSONArray("output");
        if (output == null) return "";
        for (int i = 0; i < output.length(); i++) {
            JSONObject item = output.optJSONObject(i);
            if (item == null) continue;
            JSONArray content = item.optJSONArray("content");
            if (content == null) continue;
            for (int j = 0; j < content.length(); j++) {
                JSONObject c = content.optJSONObject(j);
                if (c == null) continue;
                String text = c.optString("text", "");
                if (!text.isEmpty()) sb.append(text).append('\n');
            }
        }
        return sb.toString();
    }

    private static void validateShareUrl(String url) throws Exception {
        URL u = new URL(url == null ? "" : url.trim());
        String host = u.getHost().toLowerCase(Locale.ROOT);
        if (!"https".equalsIgnoreCase(u.getProtocol())
                || !(host.equals("chatgpt.com") || host.equals("chat.openai.com"))
                || !u.getPath().startsWith("/share/")) {
            throw new IllegalArgumentException("https://chatgpt.com/share/... 공개 공유링크를 넣어줘.");
        }
    }

    private static String getHtml(String shareUrl) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(shareUrl).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
        conn.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.7");
        int code = conn.getResponseCode();
        String html = readAll(code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream());
        conn.disconnect();
        if (code < 200 || code >= 400) throw new IllegalStateException("공유페이지 읽기 실패: HTTP " + code);
        return html;
    }

    private static String extractReadableText(String html) {
        String visible = Html.fromHtml(
                html.replaceAll("(?is)<style.*?</style>", " ")
                        .replaceAll("(?is)<svg.*?</svg>", " ")
                        .replaceAll("(?is)<noscript.*?</noscript>", " "),
                Html.FROM_HTML_MODE_LEGACY
        ).toString();
        visible = clean(visible);

        // Next/RSC 공유페이지는 대화 일부를 이스케이프된 문자열로 넣는 경우가 있어 보조 추출한다.
        String expanded = html.replace("\\n", "\n")
                .replace("\\u003c", "<").replace("\\u003e", ">")
                .replace("\\\"", "\"");
        String fallback = clean(Html.fromHtml(expanded, Html.FROM_HTML_MODE_LEGACY).toString());
        String best = fallback.length() > visible.length() ? fallback : visible;

        // 화면 UI 잡음을 줄이고 너무 긴 공백 라인을 정리한다.
        return best;
    }

    private static String clean(String text) {
        return text.replace('\u00a0', ' ')
                .replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\n\n")
                .trim();
    }

    private static List<String> chunks(String text, int size) {
        List<String> out = new ArrayList<>();
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(start + size, text.length());
            if (end < text.length()) {
                int cut = text.lastIndexOf('\n', end);
                if (cut > start + size / 2) end = cut;
            }
            out.add(text.substring(start, end));
            start = end;
        }
        return out;
    }

    private static void requireKey(String apiKey) {
        if (apiKey == null || apiKey.trim().length() < 20) {
            throw new IllegalArgumentException("OpenAI API Key를 넣어줘.");
        }
    }

    private static String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
