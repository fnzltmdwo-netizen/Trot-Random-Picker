치연 위젯 v1.3.0 - A-IDE용

ZIP 최상단에 gradlew / settings.gradle.kts / app 폴더가 바로 있습니다.

A-IDE:
1. ZIP을 새 프로젝트로 열기
2. Build/Run
3. 첫 빌드는 Gradle 9.5.0 다운로드 때문에 시간이 걸릴 수 있음

APK 예상 위치:
app/build/outputs/apk/debug/app-debug.apk

v1.3 변경:
- 시계/날짜 디자인 전면 재구성
- 4x2 중심의 더 둥근 위젯 비율
- 입력란은 OpenAI API Key + ChatGPT 공유링크 2개만
- 백엔드/APP_TOKEN 제거, Responses API 직접 호출
